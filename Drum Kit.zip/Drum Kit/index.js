let list = document.querySelectorAll(".drum");
let num = list.length;

// for pressing buttons on screen
for (let i = 0; i < num; i++) {
    list[i].addEventListener("click", function() {
        let key = this.innerHTML;
        //both works
        //document.getElementsByClassName(key)[0].style.color = "white";
        //this.style.color = "white"; 
        buttonAnimation(key);
        producesound(key);
    });

}

// for keyboard interactions

document.addEventListener("keydown", function(event) {
    //document.querySelector("." + event.key).style.color = "white";
    buttonAnimation(event.key);
    producesound(event.key);
});

// for producing sound
function producesound(key) {
    switch (key) {
        case "k":
            let audio1 = new Audio('sounds/tom-1.mp3');
            audio1.play();
            break;
        case "a":
            let audio2 = new Audio('sounds/tom-2.mp3');
            audio2.play();
            break;
        case "j":
            let audio3 = new Audio('sounds/tom-3.mp3');
            audio3.play();
            break;

        case "d":
            let audio4 = new Audio('sounds/tom-4.mp3');
            audio4.play();
            break;

        case "s":

            let audio5 = new Audio('sounds/snare.mp3');
            audio5.play();
            break;

        case "w":

            let audio6 = new Audio('sounds/crash.mp3');
            audio6.play();
            break;
        case "l":

            let audio7 = new Audio('sounds/kick-bass.mp3');
            audio7.play();
            break;

        default:
            console.log(key);
            break;

    }

}

function buttonAnimation(key) {
    let button = document.querySelector("." + key);
    button.classList.add("pressed");
    setTimeout(function() {
        button.classList.remove("pressed");
    }, 500);

}